text = "   Some spaces around   "
stripped_text = text.strip()
print("Stripped text:", stripped_text)
